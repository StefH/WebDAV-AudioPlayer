﻿namespace Blazor.FlexGrid.Demo.Shared
{
    public class CustomerAddress
    {
        public string Street { get; set; }

        public string Number { get; set; }

        public string City { get; set; }

        public int CustomerId { get; set; }
    }
}
