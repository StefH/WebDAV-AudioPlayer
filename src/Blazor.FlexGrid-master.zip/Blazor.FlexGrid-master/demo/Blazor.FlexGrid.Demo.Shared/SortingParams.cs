﻿namespace Blazor.FlexGrid.Demo.Shared
{
    public class SortingParams
    {
        public bool SortDescending { get; set; } = false;

        public string SortExpression { get; set; } = string.Empty;
    }
}
