﻿namespace Blazor.FlexGrid.Features
{
    public interface IFeature
    {
        string Name { get; }
    }
}
