﻿namespace Blazor.FlexGrid.Features
{
    public class PaginationFeature : IFeature
    {
        public string Name => nameof(PaginationFeature);
    }
}
