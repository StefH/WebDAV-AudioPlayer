﻿namespace Blazor.FlexGrid.Features
{
    public class FilteringFeature : IFeature
    {
        public string Name => nameof(FilteringFeature);
    }
}
