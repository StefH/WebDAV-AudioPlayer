﻿namespace Blazor.FlexGrid.Features
{
    public class TableHeaderFeature : IFeature
    {
        public string Name => nameof(TableHeaderFeature);
    }
}
