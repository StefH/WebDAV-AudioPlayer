﻿namespace Blazor.FlexGrid.Features
{
    public class GroupingFeature : IFeature
    {
        public string Name => nameof(GroupingFeature);
    }
}
