﻿namespace Blazor.FlexGrid.Features
{
    public class CreateItemFeature : IFeature
    {
        public string Name => nameof(CreateItemFeature);
    }
}
