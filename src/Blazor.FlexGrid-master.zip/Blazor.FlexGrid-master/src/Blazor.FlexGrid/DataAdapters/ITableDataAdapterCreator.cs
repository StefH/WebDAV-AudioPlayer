﻿namespace Blazor.FlexGrid.DataAdapters
{
    public class ITableDataAdapterCreator
    {
    }
}
