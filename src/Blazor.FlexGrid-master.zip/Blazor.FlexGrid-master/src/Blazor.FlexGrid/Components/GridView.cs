﻿using Microsoft.AspNetCore.Components;

namespace Blazor.FlexGrid.Components
{
    [Route("/gridview")]
    public class GridView : GridViewInternal
    {
    }
}
