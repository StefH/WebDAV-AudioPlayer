﻿namespace Blazor.FlexGrid.Components.Renderers
{
    public enum RendererType
    {
        InsideTag = 0,
        BeforeTag = 1,
        AfterTag = 2
    }
}
