﻿namespace Blazor.FlexGrid.Components.Configuration.ValueFormatters
{
    public enum ValueFormatterType
    {
        SingleProperty = 0,
        WholeRowObject = 1
    }
}
