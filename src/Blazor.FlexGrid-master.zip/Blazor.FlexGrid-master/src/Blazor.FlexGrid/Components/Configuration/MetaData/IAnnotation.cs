﻿namespace Blazor.FlexGrid.Components.Configuration.MetaData
{
    public interface IAnnotation
    {
        string Name { get; }

        object Value { get; }
    }
}
