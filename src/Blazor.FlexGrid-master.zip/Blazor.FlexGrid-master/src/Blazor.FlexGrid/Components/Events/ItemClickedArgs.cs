﻿namespace Blazor.FlexGrid.Components.Events
{
    public class ItemClickedArgs
    {
        public object Item { get; set; }
    }
}
