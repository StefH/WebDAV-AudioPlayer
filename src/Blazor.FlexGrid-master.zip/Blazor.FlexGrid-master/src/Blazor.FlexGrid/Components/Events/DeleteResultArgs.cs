﻿namespace Blazor.FlexGrid.Components.Events
{
    public class DeleteResultArgs
    {
        public bool ItemSuccesfullyDeleted { get; set; }

        public object Item { get; set; }
    }
}
