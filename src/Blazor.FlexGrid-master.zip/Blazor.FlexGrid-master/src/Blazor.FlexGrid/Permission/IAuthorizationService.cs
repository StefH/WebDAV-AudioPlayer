﻿namespace Blazor.FlexGrid.Permission
{
    public interface IAuthorizationService
    {
        string UserToken { get; }
    }
}
