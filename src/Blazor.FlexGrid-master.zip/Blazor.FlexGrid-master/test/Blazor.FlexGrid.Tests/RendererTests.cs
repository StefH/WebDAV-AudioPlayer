﻿using Xunit;

namespace Blazor.FlexGrid.Tests
{
    public class RendererTests
    {
        [Fact]
        public void GridBodyRendererShouldRenderTBodyTag()
        {

        }
    }
}
